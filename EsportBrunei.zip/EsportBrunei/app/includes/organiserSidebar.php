<div class="left-sidebar">
    <ul>
        <li><a href="<?php echo BASE_URL . '/organiser/events/index.php'; ?>">Manage Events</a></li>
    </ul>
</div>