<div class="left-sidebar">
    <ul>
        <li><a href="<?php echo BASE_URL . '/moderator/posts/index.php'; ?>">Manage Posts</a></li>
        <li><a href="<?php echo BASE_URL . '/moderator/players/index.php'; ?>">Manage Players</a></li>
        <li><a href="<?php echo BASE_URL . '/moderator/organiserlist/index.php'; ?>">Organiser Lists</a></li>
        <li><a href="<?php echo BASE_URL . '/moderator/topics/index.php'; ?>">Manage Topics</a></li>
        <li><a href="<?php echo BASE_URL . '/moderator/events/index.php'; ?>">Manage Events</a></li>
    </ul>
</div>