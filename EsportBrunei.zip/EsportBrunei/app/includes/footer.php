 <!-- footer -->
 <div class="footer">
    <div class="footer-content">

      <div class="footer-section about">
       <img src="<?php echo BASE_URL . "/assets/logo/logo2.png" ?>" style="width:25%;" ?>
        <h5>
         EsportBrunei is an one stop centre for gamers
</h5>
        <div class="contact">
          <h5><a href="tel:7258975" ><i class="fas fa-phone"></i> &nbsp; +673 7258975</span></a></h5>
          <h5><span><i class="fas fa-envelope"></i> &nbsp; FYPESport2021@gmail.com</span></h5>
        </div>
        <!-- <div class="socials">
          <a href="#"><i class="fab fa-facebook"></i></a>
          <a href="https://instagram.com/_Amir02"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-youtube"></i></a>
        </div> -->
      </div>

      <div class="footer-section links">
        <h2>Quick Access</h2>
        <br>
        <ul>
          <a href="<?php echo BASE_URL . '/eventsPage.php'; ?>">
            <li><i class="fa fa-calendar"></i> Events</li>
          </a>
          <a href="#">
            <li><i class="fa fa-users"></i> Team Profile</li>
          </a>
          <a href="<?php echo BASE_URL . '/aboutUs.php'; ?>">
            <li><i class="fa fa-question"></i>  About Us</li>
          </a>
          <a href="contact.php">
            <li><i class="fa fa-address-book"></i> Help </li>
          </a>
        </ul>
      </div>

      
    </div>
    <br>
    <div class="footer-bottom" >
      &copy; EsportBrunei.com | Designed by FYP Group 1
    </div>
  </div>
  <!-- // footer -->