<div id="mySidenav" class="sidenav">

<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

<div class="left-sidebar" align="center">



<!-- <a href="<?php echo BASE_URL . '/index.php' ?>" class="logo">
      <h1 class="logo-text"><span>Esport</span>Brunei</h1>
    </a> -->

    <ul>   
         <!-- Profile image display code  -->
    <?php if (isset($_SESSION['id'])){ ?>
        <?php  
                    $id = $_SESSION['id'];
                    $email_check = "SELECT * FROM users WHERE id = '$id'";
                    $res = mysqli_query($conn, $email_check);
                    if(mysqli_num_rows($res) > 0){
                        $fetch = mysqli_fetch_assoc($res);
                        $pic = $fetch['pic'];
                    } 
                    
        // Default image punya stuffz
        // $user_pic = "/assets/images/".$pic;
        // $default = "assets/uploads/avatar.png";    
        
        // if(file_exists($user_pic)){
        //     $profile_picture = $user_pic;
        // }else{
        //     $profile_picture =$default;

        // }
        
                    
        ?>
        <br>
        <br>
        <!-- profile image display code -->
        <li><img src="<?php echo BASE_URL . '/assets/profile/' . $pic; ?>" class="rounded" style="border-radius:50%;max-width:50%;" alt="Profile Image"></li>
        <li ><h1><?php echo $_SESSION['username'];?></h1></li>
        <br>
        <br>
        <li><h5><a href="<?php echo BASE_URL . '/profile.php' ?>" class="profile"><i class="fa fa-user"></i> My Profile</a></h5></li>
        <li><h5><a href="<?php echo BASE_URL . '/team-profile.php' ?>" class="TeamProfile"><i class="fa fa-users"></i> Team Management</a></h5></li>
        <li><h5><a href="<?php echo BASE_URL . '/team-registration.php' ?>" class="TeamRegistration"><i class="fa fa-user-plus"></i> Team Registration</a></h5></li>
        <?php if($_SESSION['admin']  == 0 || $_SESSION['admin']  == 1 ){ ?>
        <li><h5><a href="<?php echo BASE_URL . '/organiser-reg.php' ?>" class="organiserreg">Organiser Registration</a></h5></li> 
        <?php } ?>
        <li><h5><a href= "contact.php" ><i class="fa fa-address-book"></i> Help </a></h5></li>  
        <li><h5><a href="<?php echo BASE_URL . '/logout-user.php' ?>" class="logout">Logout</a></h5></li>
        <?php } else { ?>
       <li><h5><a href=" <?php echo BASE_URL . '/login-user.php' ?> "><i class="fa fa-user" ></i> login/Register</a></h5></li>
       <?php } ?>
    <br>   
    <br>   
     
    
    <li>Esports Brunei © 2021</li>         
    </ul>
</div>

</div>