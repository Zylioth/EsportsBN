<div class="left-sidebar">
    <ul>
        <li><a href="<?php echo BASE_URL . '/admin/posts/index.php'; ?>">Manage Posts</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/users/index.php'; ?>">Manage Users</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/players/index.php'; ?>">Manage Players</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/organiserlist/index.php'; ?>">Organiser Lists</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/topics/index.php'; ?>">Manage Topics</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/events/index.php'; ?>">Manage Events</a></li>
    </ul>
</div>